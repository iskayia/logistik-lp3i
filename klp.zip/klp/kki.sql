-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 11, 2020 at 02:16 PM
-- Server version: 8.0.21-0ubuntu0.20.04.4
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kki`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` varchar(20) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `stok` int NOT NULL,
  `satuan` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `stok`, `satuan`) VALUES
('B01', 'Standing Pen', 300, 'S01'),
('B02', 'Tempat Brosur', 1220, 'S29'),
('B03', 'Tempat Nama FO', 156, 'S29'),
('B04', 'Lem Stick', 567, 'S02'),
('B05', 'Double Tip Besar', 167, 'S02'),
('B06', 'Trigional Clip', 256, 'S02'),
('B07', 'Binder Clip No.155', 267, 'S02'),
('B08', 'Kertas A4', 278, 'S11'),
('B09', 'Kertas F4', 256, 'S11'),
('B10', 'kertas Kop', 2, 'S04'),
('B11', 'Kalkulator', 1, 'S01'),
('B12', 'Bindex Besar', 4, 'S02'),
('B13', 'Bindex Kecil', 4, 'S02'),
('B14', 'Note Kuning', 4, 'S04'),
('B15', 'Tipe - X Kertas', 1, 'S01'),
('B16', 'penggaris', 1, 'S01'),
('B17', 'Penghapus Papan Tulis', 1, 'S02'),
('B18', 'Perfurator', 1, 'S01'),
('B19', 'Steples', 1, 'S01'),
('B20', 'Isi Steples', 3, 'S02'),
('B21', 'Kwitansi Pendaftaran', 5, 'S04'),
('B22', 'Paku Mading', 1, 'S02'),
('B23', 'Sterofoam', 1, 'S02'),
('B24', 'Spidol Non Permanen', 4, 'S02'),
('B25', 'Concord A4', 2, 'S04'),
('B26', 'Trigional Clip No. 1', 2, 'S02'),
('B27', 'Post it 3 X 3', 2, 'S01'),
('B28', 'Tinta Spidol Hitam', 2, 'S13'),
('B29', 'Tinta Spidol Biru', 2, 'S13'),
('B30', 'Double Tip Sedang', 3, 'S02'),
('B31', 'Bolpoint Gsof', 3, 'S02'),
('B32', 'Bolpoint B, Live', 2, 'S02'),
('B33', 'Bolpoint Snow 0.5', 2, 'S02'),
('B34', 'Buku Besar Notulen', 3, 'S01'),
('B35', 'Gunting', 3, 'S01'),
('B36', 'Bisnis File', 3, 'S01'),
('B37', 'Bantex Kecil', 2, 'S01'),
('B38', 'Box File', 3, 'S01'),
('B39', 'Penstand', 3, 'S01'),
('B40', 'FD Hp x 32GB', 1, 'S01'),
('B41', 'Stabilo Warna Warni', 2, 'S02'),
('B42', 'Pulpen Boxi 0,6', 3, 'S02'),
('B43', 'Stabilo Warna', 2, 'S02'),
('B44', 'sesuatunya apa ya', 2, 'S06'),
('B45', '21', 12, 'S09'),
('B46', 'detol', 2, 'S13'),
('B47', 'kentang', 300, 'S08'),
('B48', 'saos', 15, 'S13');

-- --------------------------------------------------------

--
-- Table structure for table `barang_keluar`
--

CREATE TABLE `barang_keluar` (
  `id_barang_keluar` varchar(255) NOT NULL,
  `tgl_brg_keluar` varchar(255) DEFAULT NULL,
  `id_barang` varchar(255) DEFAULT NULL,
  `jml_brg_keluar` varchar(255) DEFAULT NULL,
  `id_user` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang_keluar`
--

INSERT INTO `barang_keluar` (`id_barang_keluar`, `tgl_brg_keluar`, `id_barang`, `jml_brg_keluar`, `id_user`, `status`) VALUES
('BK-201202125751', '2020-12-02', 'B01', '13', NULL, NULL),
('BK-201202130920', '2020-12-02', 'B03', '28', NULL, NULL),
('BK-201202134510', '2020-12-02', 'B01', '15', NULL, NULL),
('BK-201202135150', '2020-12-02', 'B01', '25', NULL, NULL),
('BK-201202135235', '2020-12-02', 'B02', '35', NULL, NULL),
('BK-201203195141', '2020-12-03', 'B02', '5', NULL, NULL),
('BK-201204132836', '2020-12-04', 'B09', '10', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `barang_masuk`
--

CREATE TABLE `barang_masuk` (
  `id_barang_masuk` varchar(20) NOT NULL,
  `tgl_barang_masuk` varchar(20) NOT NULL,
  `id_barang` varchar(20) NOT NULL,
  `jumlah_brg_masuk` varchar(20) NOT NULL,
  `harga_satuan` varchar(100) NOT NULL,
  `jumlah_harga` varchar(255) NOT NULL,
  `status` enum('proses','diterima','ditolak','selesai') NOT NULL,
  `id_user` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `barang_masuk`
--

INSERT INTO `barang_masuk` (`id_barang_masuk`, `tgl_barang_masuk`, `id_barang`, `jumlah_brg_masuk`, `harga_satuan`, `jumlah_harga`, `status`, `id_user`) VALUES
('BM-201205102631', '2020-12-05', 'B09', '2', '1', '5', '', '1'),
('BM-201205112056', '2020-11-27', 'B01', '11', '11', '1', 'proses', '1'),
('BM-201205112554', '2020-12-05', 'B14', '1', '111', '1', '', '1'),
('BM-201205112729', '2020-12-05', 'B01', '2', '3333', '444', 'proses', '2'),
('BM-201205171406', '2020-12-05', 'B02', '5', '5', '1', 'proses', '1'),
('BM-201205171407', '2020-12-05', 'B03', '5', '6', '7', 'diterima', '4'),
('BM-201205171954', '2020-12-05', 'B08', '2', '22', '222', 'proses', '1'),
('BM-201206085059', '2020-12-06', 'B05', '2', '2', '22', 'proses', '1'),
('BM-201206085355', '2020-12-06', 'B07', '2', '2', '22', 'diterima', '2'),
('BM-201206085802', '2020-12-06', 'B16', '2', '2', '22', 'diterima', '2'),
('BM-2012060900220', '2020-12-06', 'B17', '2', '22', '2', 'proses', '2'),
('BM-2012060900221', '2020-12-06', 'B18', '3', '33', '3', 'proses', '1'),
('BM-2012061009120', '2020-12-06', 'B19', '1', '22', '22', 'proses', '2'),
('BM-2012061009580', '2020-12-06', 'B23', '1', '11', '11', 'proses', '2'),
('BM-2012061009581', '2020-12-06', 'B24', '2', '22', '44', 'proses', '2'),
('BM-2012091532480', '2020-12-09', 'B45', '12', '10000', '120000', 'proses', '2'),
('BM-2012091534370', '2020-12-09', 'B46', '2', '3000', '6000', 'proses', '2'),
('BM-2012091537220', '2020-12-09', 'B47', '300', '25000', '7500000', 'proses', '2'),
('BM-2012091537221', '2020-12-09', 'B48', '15', '2000', '30000', 'proses', '2');

-- --------------------------------------------------------

--
-- Table structure for table `divisi`
--

CREATE TABLE `divisi` (
  `id_divisi` varchar(20) NOT NULL,
  `divisi` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `divisi`
--

INSERT INTO `divisi` (`id_divisi`, `divisi`) VALUES
('D01', 'Pemasaran'),
('D02', 'Akademik'),
('D03', 'Keuangan'),
('D04', 'C&P'),
('D05', 'General Affair'),
('D06', 'Pimpinan'),
('D07', 'Hrd');

-- --------------------------------------------------------

--
-- Table structure for table `satuan`
--

CREATE TABLE `satuan` (
  `id_satuan` varchar(20) NOT NULL,
  `nama_satuan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `satuan`
--

INSERT INTO `satuan` (`id_satuan`, `nama_satuan`) VALUES
('S01', 'Unit'),
('S02', 'Buah'),
('S03', 'Pasang'),
('S04', 'Lembar'),
('S05', 'Keping'),
('S06', 'Batang'),
('S07', 'Bungkus'),
('S08', 'Potong'),
('S09', 'Tablet'),
('S10', 'Ekor'),
('S11', 'Rim'),
('S12', 'Karat'),
('S13', 'Botol'),
('S14', 'Butir'),
('S15', 'Roll'),
('S16', 'Dus'),
('S17', 'Karung'),
('S18', 'Koli'),
('S19', 'Sak'),
('S20', 'Bal'),
('S21', 'Kaleng'),
('S22', 'Set'),
('S23', 'Slop'),
('S24', 'Gulung'),
('S25', 'Ton'),
('S26', 'Kilo Gram'),
('S27', 'Gram'),
('S28', 'Mili Gram'),
('S29', 'Meter'),
('S30', 'M2'),
('S31', 'M3'),
('S32', 'Inchi'),
('S33', 'Cc'),
('S34', 'Liter');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` varchar(20) NOT NULL,
  `id_divisi` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `jenis_kelamin` enum('Pria','Wanita') NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `no_hp` varchar(25) NOT NULL,
  `tentang` varchar(255) NOT NULL,
  `level` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `id_divisi`, `username`, `password`, `nama_lengkap`, `email`, `jenis_kelamin`, `alamat`, `no_hp`, `tentang`, `level`) VALUES
('1', 'D02', 'yaya', '123', 'Siska bch', 'sska', 'Wanita', 'Sentul', '08123', 'semangat', 'staff'),
('2', 'D05', 'via', '234', 'via', 'apa aja', 'Wanita', 'Cilodong', '08234', 'fighting', 'admin'),
('3', 'D03', 'erdi', '345', 'Erdiiiiiiiii', 'erdi', 'Pria', 'Bogor', '08345', 'ganbatte', 'keuangan'),
('4', 'D02', 'indana', '456', 'indanaaa', 'indan', 'Wanita', 'Cibinong', '08456', 'jia you', 'kabid'),
('5', 'D05', 'farizal', '567', 'bapak farizal', 'pimpinan123@gmail,com', 'Pria', 'jakarta', '08567', 'saya pimpinan', 'pimpinan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `barang_keluar`
--
ALTER TABLE `barang_keluar`
  ADD PRIMARY KEY (`id_barang_keluar`);

--
-- Indexes for table `barang_masuk`
--
ALTER TABLE `barang_masuk`
  ADD PRIMARY KEY (`id_barang_masuk`);

--
-- Indexes for table `divisi`
--
ALTER TABLE `divisi`
  ADD PRIMARY KEY (`id_divisi`);

--
-- Indexes for table `satuan`
--
ALTER TABLE `satuan`
  ADD PRIMARY KEY (`id_satuan`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
