<?php
// get id barang untuk proses hapus
include "koneksi.php";
$hapus = mysqli_query($koneksi, "DELETE FROM barang WHERE id_barang='$_GET[id_barang]'");

header('location:barang.php');