<?php
// get id barang untuk proses hapus
include "koneksi.php";
$hapus = mysqli_query($koneksi, "DELETE FROM satuan WHERE id_satuan='$_GET[id_satuan]'");

header('location:satuan.php');