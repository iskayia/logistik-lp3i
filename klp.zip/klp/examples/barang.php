<?php $menu = 'pengajuan'; ?>
<?php include 'header.php'; ?>

<?php
//membuat format rupiah dengan PHP
//tutorial www.malasngoding.com

function rupiah($angka)
{

    $hasil_rupiah = "" . number_format($angka, 0, '', '.');
    return $hasil_rupiah;
}

function rp($angka)
{

    $hasil_rupiah = "Rp. " . number_format($angka, 0, '', '.');
    return $hasil_rupiah;
}
?>
<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card card-stats card-round">
                        <div class="card-body ">

                            <div class="ml-3">
                                     
                                <a href="tambah_barang.php" class="btn btn-primary btn-xs"><i class="fa fa-plus"></i> Tambah Data</a>
                                
                            </div>
                            
                            <br>
                            
                            <div style="overflow-x: auto;">
                                <table class=" table table-bordered display nowrap fixed" id="tabel-data" style="font-size: 16px;" id="tabel-data">
                                    <col width="90px">
                                    <col width="150px">
                                    <col width="200px">
                                    <col width="150px">
                                    <col width="150px">
                                    <thead>
                                        <tr align="center">
                                            <th>No</th>
                                            <th>Nama Barang</th>
                                            <th>Stok</th>
                                            <th>Satuan</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php


                                        // $Halaman = 1;

                                        // if(isset($_GET['page'])){
                                        //     $Halaman= $_GET['page'];
                                        // }

                                        // $Rows = 10;
                                        // $Record = ($Halaman - 1) * $Rows;
                                        
                                        // halaman 1 -> 0
                                        // halaman 2 -> 10
                                        // halamn 3 -> 20

                                        $sql = mysqli_query($koneksi, "SELECT * FROM `barang` inner join satuan on satuan.id_satuan =barang.satuan ");
                                        while ($s = mysqli_fetch_array($sql)) {
                                        ?>
                                            <tr>
                                               
                                                <td align="center"><?= $s["id_barang"]; ?></td>
                                                <td align="center"><?= $s["nama_barang"]; ?></td>
                                                <td align="center"><?= $s["stok"]; ?></td>
                                                <td align="center"><?= $s["nama_satuan"]; ?></td>
                                                <td align="center"><a href="edit_barang.php?id_barang=<?= $s['id_barang']; ?>" class='far fa-edit'></a>
                                                   
                                                    
                                                     <a href="hapus_barang.php?id_barang=<?= $s['id_barang']; ?>" class='far fa-trash-alt'></a>
                                                       <!--  <button type="button" class="btn btn-danger" id="alert_demo_8">Show me</button>  -->
                                                </td>
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                               <!--  <?php
                                $PrevPage = $Halaman - 1;
                                if($PrevPage < 1) $PrevPage = 1;
                                ?>
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                      <a href="?page=<?= $PrevPage; ?>" type="button" class="btn btn-secondary">
                                          <i class="fas fa-arrow-left"></i>
                                      </a>
                                      <a href="?page=<?= $Halaman + 1; ?>" type="button" class="btn btn-secondary">
                                           <i class="fas fa-arrow-right"></i>
                                      </a>
                                    </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>        

<script>
    $(document).ready(function(){
        $('#tabel-data').DataTable();
    });
</script>

     <script>
    //     //== Class definition
    //     var SweetAlert2Demo = function() {

    //         //== Demos
    //         var initDemos = function() {
    //             //== Sweetalert Demo 1
    //             $('#alert_demo_1').click(function(e) {
    //                 swal('Good job!', {
    //                     buttons: {                  
    //                         confirm: {
    //                             className : 'btn btn-success'
    //                         }
    //                     },
    //                 });
    //             });

    //             //== Sweetalert Demo 2
    //             $('#alert_demo_2').click(function(e) {
    //                 swal("Here's the title!", "...and here's the text!", {
    //                     buttons: {                  
    //                         confirm: {
    //                             className : 'btn btn-success'
    //                         }
    //                     },
    //                 });
    //             });

    //             //== Sweetalert Demo 3
    //             $('#alert_demo_3_1').click(function(e) {
    //                 swal("Good job!", "You clicked the button!", {
    //                     icon : "warning",
    //                     buttons: {                  
    //                         confirm: {
    //                             className : 'btn btn-warning'
    //                         }
    //                     },
    //                 });
    //             });

    //             $('#alert_demo_3_2').click(function(e) {
    //                 swal("Good job!", "You clicked the button!", {
    //                     icon : "error",
    //                     buttons: {                  
    //                         confirm: {
    //                             className : 'btn btn-danger'
    //                         }
    //                     },
    //                 });
    //             });

    //             $('#alert_demo_3_3').click(function(e) {
    //                 swal("Good job!", "You clicked the button!", {
    //                     icon : "success",
    //                     buttons: {                  
    //                         confirm: {
    //                             className : 'btn btn-success'
    //                         }
    //                     },
    //                 });
    //             });

    //             $('#alert_demo_3_4').click(function(e) {
    //                 swal("Good job!", "You clicked the button!", {
    //                     icon : "info",
    //                     buttons: {                  
    //                         confirm: {
    //                             className : 'btn btn-info'
    //                         }
    //                     },
    //                 });
    //             });

    //             //== Sweetalert Demo 4
    //             $('#alert_demo_4').click(function(e) {
    //                 swal({
    //                     title: "Good job!",
    //                     text: "You clicked the button!",
    //                     icon: "success",
    //                     buttons: {
    //                         confirm: {
    //                             text: "Confirm Me",
    //                             value: true,
    //                             visible: true,
    //                             className: "btn btn-success",
    //                             closeModal: true
    //                         }
    //                     }
    //                 });
    //             });

    //             $('#alert_demo_5').click(function(e){
    //                 swal({
    //                     title: 'Input Something',
    //                     html: '<br><input class="form-control" placeholder="Input Something" id="input-field">',
    //                     content: {
    //                         element: "input",
    //                         attributes: {
    //                             placeholder: "Input Something",
    //                             type: "text",
    //                             id: "input-field",
    //                             className: "form-control"
    //                         },
    //                     },
    //                     buttons: {
    //                         cancel: {
    //                             visible: true,
    //                             className: 'btn btn-danger'
    //                         },                  
    //                         confirm: {
    //                             className : 'btn btn-success'
    //                         }
    //                     },
    //                 }).then(
    //                 function() {
    //                     swal("", "You entered : " + $('#input-field').val(), "success");
    //                 }
    //                 );
    //             });

    //             $('#alert_demo_6').click(function(e) {
    //                 swal("This modal will disappear soon!", {
    //                     buttons: false,
    //                     timer: 3000,
    //                 });
    //             });

    //             $('#alert_demo_7').click(function(e) {
    //                 swal({
    //                     title: 'Are you sure?',
    //                     text: "You won't be able to revert this!",
    //                     type: 'warning',
    //                     buttons:{
    //                         confirm: {
    //                             text : 'Yes, delete it!',
    //                             className : 'btn btn-success'
    //                         },
    //                         cancel: {
    //                             visible: true,
    //                             className: 'btn btn-danger'
    //                         }
    //                     }
    //                 }).then((Delete) => {
    //                     if (Delete) {
    //                         swal({
    //                             title: 'Deleted!',
    //                             text: 'Your file has been deleted.',
    //                             type: 'success',
    //                             buttons : {
    //                                 confirm: {
    //                                     className : 'btn btn-success'
    //                                 }
    //                             }
    //                         });
    //                     } else {
    //                         swal.close();
    //                     }
    //                 });
    //             });

    //             $('#alert_demo_8').click(function(e) {
    //                 swal({
    //                     title: 'Are you sure?',
    //                     text: "You won't be able to revert this!",
    //                     type: 'warning',
    //                     buttons:{
    //                         cancel: {
    //                             visible: true,
    //                             text : 'No, cancel!',
    //                             className: 'btn btn-danger'
    //                         },                  
    //                         confirm: {
    //                             text : 'Yes, delete it!',
    //                             className : 'btn btn-success'
    //                         }
    //                     }
    //                 }).then((willDelete) => {
    //                     if (willDelete) {
    //                         swal("Poof! Your imaginary file has been deleted!", {
    //                             icon: "success",
    //                             buttons : {
    //                                 confirm : {
    //                                     className: 'btn btn-success'
    //                                 }
    //                             }
    //                         });
    //                     } else {
    //                         swal("Your imaginary file is safe!", {
    //                             buttons : {
    //                                 confirm : {
    //                                     className: 'btn btn-success'
    //                                 }
    //                             }
    //                         });
    //                     }
    //                 });
    //             })

    //         };

    //         return {
    //             //== Init
    //             init: function() {
    //                 initDemos();
    //             },
    //         };
    //     }();

    //     //== Class Initialization
    //     jQuery(document).ready(function() {
    //         SweetAlert2Demo.init();
    //     });
    </script>

<?php include 'footer.php'; ?>