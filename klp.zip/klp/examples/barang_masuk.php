<?php $menu = 'pengajuanS'; ?>
<?php include 'header.php'; ?>

<?php
//membuat format rupiah dengan PHP
//tutorial www.malasngoding.com

function rupiah($angka)
{

    $hasil_rupiah = "" . number_format($angka, 0, '', '.');
    return $hasil_rupiah;
}

function rp($angka)
{

    $hasil_rupiah = "Rp. " . number_format($angka, 0, '', '.');
    return $hasil_rupiah;
}
?>
<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card card-stats card-round">
                        <div class="card-body ">

                            <div class="ml-3">
                            <a href="tambah_barang_masuk.php" class="btn btn-primary btn-xs"><i class="fa fa-plus"></i> Tambah Data Bulanan</a>
                            <a href="tambah_barang_masuk_urgen.php" class="btn btn-primary btn-xs"><i class="fa fa-plus"></i> Tambah Data Urgent</a>
                            </div>

                            <br>
                            <div style="overflow-x: auto;">
                                <table class=" table table-bordered display nowrap fixed" id="tabel-data" style="font-size: 16px;" id="tabel-data">
                                    <col width="50px">
                                    <col width="150px">
                                    <col width="150px">
                                    <col width="200px">
                                    <col width="150px">
                                    <col width="150px">
                                    <thead>
                                        <tr align="center">
                                            <th>No</th>
                                            <th>ID Barang Masuk</th>
                                            <th>Tanggal Barang Masuk</th>
                                            <th>Nama Barang</th>
                                            <th>Jumlah Barang Masuk</th>
                                            <th>Harga Satuan</th>
                                            <th>Jumlah Harga</th>
                                            <th>Status</th>
                                            <th>ID User</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i = 1 ?>
                                        <?php
                                        //  $Halaman = 1;

                                        // if(isset($_GET['page'])){
                                        //     $Halaman= $_GET['page'];
                                        // }

                                        // $Rows = 10;
                                        // $Record = ($Halaman - 1) * $Rows;
                                        
                                        // halaman 1 -> 0
                                        // halaman 2 -> 10
                                        // halamn 3 -> 20

                                        $sql = mysqli_query($koneksi, "SELECT * FROM `barang_masuk` INNER JOIN barang on barang.id_barang = barang_masuk.id_barang INNER JOIN user on user.id_user = barang_masuk.id_user  ");
                                        while ($s = mysqli_fetch_array($sql)) {
                                        ?>
                                            <tr>
                                                <td align="center"><?= $i++; ?></td>
                                                <td align="center"><?= $s["id_barang_masuk"]; ?></td>
                                                <td align="center"><?= $s["tgl_barang_masuk"]; ?></td>
                                                <td align="center"><?= $s["nama_barang"]; ?></td>
                                                <td align="center"><?= $s["jumlah_brg_masuk"]; ?></td>
                                                <td align="center"><?= $s["harga_satuan"]; ?></td>
                                                <td align="center"><?= $s["jumlah_harga"]; ?></td>
                                                <td align="right"><?= $s["status"]; ?></td>
                                                <td align="center"><?= $s["username"]; ?></td>
                                                <td align="center"><i class='far fa-edit'></i>
                                                    <a href="hapus_barang_masuk.php?id_barang_masuk=<?= $s['id_barang_masuk']; ?>" class='far fa-trash-alt'></a>
                                                </td>
                                                <!-- <td align="right"><?= rupiah($s["status"]); ?></td> -->
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                                 <!--  <?php
                                $PrevPage = $Halaman - 1;
                                if($PrevPage < 1) $PrevPage = 1;
                                ?>
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                      <a href="?page=<?= $PrevPage; ?>" type="button" class="btn btn-secondary">
                                          <i class="fas fa-arrow-left"></i>
                                      </a>
                                      <a href="?page=<?= $Halaman + 1; ?>" type="button" class="btn btn-secondary">
                                           <i class="fas fa-arrow-right"></i>
                                      </a>
                                    </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>    

<!-- modal add data dibuka-->
<script>
  function openForm() {
    document.getElementById("myForm").style.display = "block";
  }

  function closeForm() {
    document.getElementById("myForm").style.display = "none";
  }
</script>

<script>
    $(document).ready(function(){
        $('#tabel-data').DataTable();
    });
</script>

<?php include 'footer.php'; ?>