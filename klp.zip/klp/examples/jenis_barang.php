<?php $menu = 'pengajuanS'; ?>
<?php include 'header.php'; ?>

<?php
//membuat format rupiah dengan PHP
//tutorial www.malasngoding.com

function rupiah($angka)
{

    $hasil_rupiah = "" . number_format($angka, 0, '', '.');
    return $hasil_rupiah;
}

function rp($angka)
{

    $hasil_rupiah = "Rp. " . number_format($angka, 0, '', '.');
    return $hasil_rupiah;
}
?>
<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card card-stats card-round">
                        <div class="card-body ">
                            <a href="tambah_jenis_barang.php">Tambah Data</a>
                            <br>
                            <div style="overflow-x: auto;">
                                <table class=" table table-bordered display nowrap fixed" id="tabel-data" style="font-size: 16px;">
                                    <col width="50px">
                                    <col width="150px">
                                    <col width="150px">
                                    <col width="200px">
                                    <col width="150px">
                                    <col width="150px">
                                    <thead>
                                        <tr align="center">
                                            <th>No</th>
                                            <th>ID Jenis Barang</th>
                                            <th>Jenis Barang</th>
                                            <th>Tanggal Entri</th>
                                            <th>Action</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i = 1 ?>
                                        <?php
                                        $sql = mysqli_query($koneksi, "SELECT * FROM jenis_barang ORDER BY id_jenis_barang ASC");
                                        while ($s = mysqli_fetch_array($sql)) {
                                        ?>
                                            <tr>
                                                <td align="center"><?= $i++; ?></td>
                                                <td align="center"><?= $s["id_jenis_barang"]; ?></td>
                                                <td align="center"><?= $s["jenis_barang"]; ?></td>
                                                <td align="center"><?= $s["tgl_entri"]; ?></td>
                                                <td align="center"><i class='far fa-edit'></i>
                                                    <i class='far fa-trash-alt'></i>
                                                </td>
                                               
                                                <!-- <td align="right"><?= rupiah($s["status"]); ?></td> -->
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>        
<?php include 'footer.php'; ?>