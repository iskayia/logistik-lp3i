<?php  
session_start();
if( isset($_SESSION['login'])){
	include "koneksi.php";
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Cetak Laporan Stok Barang</title>

		<link rel="icon" href="../assets/img/logolp3i.png" type="image/x-icon" />

    <!-- Fonts and icons -->
    <script src="../assets/js/plugin/webfont/webfont.min.js"></script>
    <script>
        WebFont.load({
            google: {
                "families": ["Open+Sans:300,400,600,700"]
            },
            custom: {
                "families": ["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands"],
                urls: ['../assets/css/fonts.css']
            },
            active: function() {
                sessionStorage.fonts = true;
            }
        });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/azzara.min.css">

    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link rel="stylesheet" href="../assets/css/demo.css">

    <!-- css untuk membuat data table -->
  
     <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css" /> -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" />

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>

		
		<style>
			body{
				font-family: Arial;
                width: '100%';
			}

			@media print{
				.no-print{
					display: none;
				}
			}

			table{
				border-collapse: collapse;
                
			}
            /*.center  { text-align: center;}*/

		</style>


	</head>
	<body>
        <div class="container d-flex justify-content-center">
            <div class="row col-md-12 d-flex justify-content-center">
                    <div align="center" style="width:100%" >
                        <h3 style="font-weight: bold;" >LAPORAN STOK BARANG</h3>
                        <H3 style="font-weight: bold;">LOGISTIK ATK</H3>
                        <H3 style="font-weight: bold;">LP3I KAMPUS CILODONG</H3>
                        <hr>
                    </div>
                    <table class=" table table-bordered display nowrap fixed" id="tabel-data" style="font-size: 16px; " id="tabel-data" >
                                                <col width="90px">
                                                <col width="150px">
                                                <col width="150px">
                                                <col width="150px">
                                                <thead>
                                                    <tr align="center">
                                                        <th>No</th>
                                                        <th>Nama Barang</th>
                                                        <th>Stok</th>
                                                        <th>Satuan</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php


                                                    $sql = mysqli_query($koneksi, "SELECT * FROM `barang` inner join satuan on satuan.id_satuan =barang.satuan ");
                                                    while ($s = mysqli_fetch_array($sql)) {
                                                    ?>
                                                        <tr>
                                                           
                                                            <td align="center"><?= $s["id_barang"]; ?></td>
                                                            <td align="center"><?= $s["nama_barang"]; ?></td>
                                                            <td align="center"><?= $s["stok"]; ?></td>
                                                            <td align="center"><?= $s["nama_satuan"]; ?></td>
                                                        </tr> 
                                                    <?php
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                    <br>
                    
                    <table width="100%">
                        <tr>
                            <td></td>
                            <td width="200px">
                                <p>Cilodong, <?php echo date('d F Y'); ?><br>Operator GA,</p>
                                <br>
                                <br>
                                <br>
                                <p>_________________________</p>
                            </td>
                        </tr>   
                    </table>
                    <br>
                    <div align="center" style="margin-bottom: 40px">
                        <a href="#" onclick="window.print();" class="btn btn-primary btn-lg no-print">
                            <i class="fa fa-print" aria-hidden="true"></i> Print 
                        </a>
                    </div>  

            </div>
        </div>
	</body>
</html>

<?php  
}else{
	header('location:login.php');
}
?>