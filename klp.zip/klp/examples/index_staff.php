<?php include "header_staff.php"; ?>
    <div class="main-panel">
        <div class="content">
            <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Beranda</h4>
                <div class="btn-group btn-group-page-header ml-auto">
                    <button type="button" class="btn btn-light btn-round btn-page-header-dropdown dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa fa-ellipsis-h"></i>
                    </button>

                    <div class="dropdown-menu">
                        <div class="arrow"></div>
                        <a class="dropdown-item" href="#">Action</a>
                        <a class="dropdown-item" href="#">Another action</a>
                        <a class="dropdown-item" href="#">Something else here</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">Separated link</a>
                    </div>

                </div>
            </div>

            <div class="row">
                <div class="col-sm-6 col-md-3">
                    <div class="card card-stats card-round">
                        <div class="card-body ">
                            <div class="row align-items-center">
                                <div class="col-icon">
                                    <div class="icon-big text-center icon-primary bubble-shadow-small">
                                        <i class="fas fa-users"></i>
                                    </div>
                                </div>
                                <div class="col col-stats ml-3 ml-sm-0">
                                    <div class="numbers">
                                        <?php

                                            $sql = "SELECT COUNT(jml_brg_keluar) AS tbk FROM `barang_keluar`";
                                            $query = mysqli_query($koneksi,$sql);
                                            $result= mysqli_fetch_array($query);
                                            
                                        ?>
                                        <p class="card-category">Transaksi Barang Keluar</p>
                                        <h4 class="card-title"><?= $result['tbk'];?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="card card-stats card-round">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-icon">
                                    <div class="icon-big text-center icon-info bubble-shadow-small">
                                        <i class="far fa-newspaper"></i>
                                    </div>
                                </div>
                                <div class="col col-stats ml-3 ml-sm-0">
                                    <div cl ass="numbers">
                                         <?php

                                            $sql = "SELECT COUNT(jumlah_brg_masuk) AS tbm FROM `barang_masuk`";
                                            $query = mysqli_query($koneksi,$sql);
                                            $result= mysqli_fetch_array($query);
                                            
                                        ?>
                                        <p class="card-category">Transaksi Barang Masuk</p>
                                        <h4 class="card-title"><?= $result['tbm']?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="card card-stats card-round">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-icon">
                                    <div class="icon-big text-center icon-success bubble-shadow-small">
                                        <i class="far fa-chart-bar"></i>
                                    </div>
                                </div>
                                <div class="col col-stats ml-3 ml-sm-0">
                                    <div class="numbers">
                                         <?php

                                            $sql = "SELECT SUM(stok) as stk FROM `barang`";
                                            $query = mysqli_query($koneksi,$sql);
                                            $result= mysqli_fetch_array($query);
                                            
                                        ?>
                                        <p class="card-category">Stok</p>
                                        <h4 class="card-title"><?= $result['stk']?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="card card-stats card-round">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-icon">
                                    <div class="icon-big text-center icon-secondary bubble-shadow-small">
                                        <i class="far fa-check-circle"></i>
                                    </div>
                                </div>
                                <div class="col col-stats ml-3 ml-sm-0">
                                    <div class="numbers">
                                        <p class="card-category">Order</p>
                                        <h4 class="card-title">576</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <!-- tampilan utama barang keluar -->
                <div class="col-md-6">
                    <div class="card card-stats card-round">
                        <div class="card-body ">
                            <!-- <a href="tambah_barang_masuk.php">Tambah Data</a> -->
                            <br>
                            <div style="overflow-x: auto;">
                                <table class=" table table-bordered display nowrap fixed" id="tabel-data" style="font-size: 16px;">
                                    <col width="100px">
                                    <col width="100px">
                                    <col width="100px">
                                    <thead>
                                        <tr align="center">
                                            <th>Barang Keluar</th>
                                            <th>Tanggal Keluar</th>
                                            <th>Jumlah Barang Keluar</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php

                                        $sql = mysqli_query($koneksi, "SELECT nama_barang,tgl_brg_keluar,jml_brg_keluar FROM `barang_keluar` INNER JOIN barang on barang.id_barang = barang_keluar.id_barang ");
                                        while ($s = mysqli_fetch_array($sql)) {
                                        ?>
                                            <tr>
                                                <td align="center"><?= $s["nama_barang"];?></td>
                                                <td align="center"><?= $s["tgl_brg_keluar"]; ?></td>
                                                <td align="center"><?= $s["jml_brg_keluar"]; ?></td>
                                        <?php
                                            }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- tampilan utama barang Masuk -->
                <div class="col-md-6">
                    <div class="card card-stats card-round">
                        <div class="card-body ">
                            <!-- <a href="tambah_barang_masuk.php">Tambah Data</a> -->
                            <br>
                            <div style="overflow-x: auto;">
                                <table class=" table table-bordered display nowrap fixed" id="tabel-data" style="font-size: 16px;">
                                    <col width="50px">
                                    <col width="150px">
                                    <col width="150px">
                                    <thead>
                                        <tr align="center">
                                            <th>Barang Masuk</th>
                                            <th>Tanggal Masuk</th>
                                            <th>Jumlah Barang Masuk</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php

                                        $sql = mysqli_query($koneksi, "SELECT nama_barang,tgl_barang_masuk,jumlah_brg_masuk FROM `barang_masuk`INNER JOIN barang on barang.id_barang = barang_masuk.id_barang ");
                                        while ($s = mysqli_fetch_array($sql)) {
                                        ?>
                                            <tr>
                                                <td align="center"><?= $s["nama_barang"];?></td>
                                                <td align="center"><?= $s["tgl_barang_masuk"]; ?></td>
                                                <td align="center"><?= $s["jumlah_brg_masuk"]; ?></td>
                                        <?php
                                            }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>


            </div>

                   

    <?php include "footer_staff.php"; ?>