<?php 
    include 'header.php'; 

     session_start();
    $jmlform = 1;
    if(isset($_GET['jmlform'])){
        $jmlform = $_GET['jmlform'];
    }
    $tambah = "?jmlform=" . (intval($jmlform) + 1);
    $kurang = "?jmlform=" . (intval($jmlform) - 1);
    
?>

<div class="main-content">
    <div class="container-fluid">
        <!-- <ol class="breadcrumb mb-4" style="font-size: 16px">
            <li><i class="fa fa-home" aria-hidden="true"></i></li>
            <li class="breadcrumb-item" style="margin-left: 10px"><a href="index.php">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="simpanan_wajib.php">Simpanan</a></li>
            <li class="breadcrumb-item no-drop active">Tambah Simpanan</li>

        </ol> -->
        <div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card card-stats card-round">
                        <div class="card-body ">

                        <div class="row clearfix">
                            <a href="barang_masuk.php"><button type="button" class="btn btn-danger btn-sm"><i class="ik ik-arrow-left"></i>&nbsp; Kembali</button></a>
                        </div>

                        <br>
                        <form method="post" action="" class="was-validated font-weight-small">
                            <?php 
                                if($jmlform >= 1) {
                             ?>
                            <a href="<?= $tambah; ?>" type="button" id="tambahForm" class="btn btn-info" style=" position: absolute; right: 10px; top: 10px;" ><i class='fa-plus fas'></i></a>
                            
                            <?php 
                                }
                                if($jmlform > 1) {
                             ?>
                                <a href="<?= $kurang; ?>" type="button" id="kurangForm" class="btn btn-info" style=" position: absolute; left:900px; top: 10px;" ><i class='fa-minus fas'></i></a>
                             <?php 
                                }
                              ?>

                            <div class="row">
                                <div class="col-md-12">
                                    <?php
                                    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

                                        $tersimpan = true;

                                        for($key = 0; $key < $jmlform; $key++) {
                                            $idBarangMasuk         = 'BM-'.date('ymdHis').$key;
                                            $tglBarangMasuk        = $_POST['tgl_barang_masuk'.$key];
                                            $idBarang              = $_POST['id_barang'.$key];
                                            $jumlahBarangMasuk     = $_POST['jumlah_brg_masuk'.$key];
                                            $hargaSatuan           = $_POST['harga_satuan'.$key];
                                            $jumlahHarga           = $_POST['jumlah_harga'.$key];
                                            $status                = 'proses';
                                            $idUser                =  $_SESSION['id_user'];
                                            $satuan                = $_POST['id_satuan'.$key];
                                            $namaBarang            = $_POST['nama_barang'.$key];

                                            // var_dump('id bm: '.$idBarangMasuk . '  tgl barang m' . $tglBarangMasuk . ' idbarang : ' . $idBarang . ' jml bm : ' . $jumlahBarangMasuk . ' harga s : '. $hargaSatuan.' jml hr :' . $jumlahHarga.' sts :'. $status.' iduser :'.$idUser.'satuan :'.$satuan);
                                            // die();

                                            if ($tglBarangMasuk == '' | $idBarang == '' | $jumlahBarangMasuk == '' | $hargaSatuan == '' | $jumlahHarga == '' ) {
                                                echo "<div class='alert alert-warning fade show alert-dismissible mt-2'>
                                                            Data Belum lengkap !!!
                                                        </div>";
                                            } else {

                                                $simpanBarang = mysqli_query(
                                                    $koneksi,
                                                    "INSERT INTO  `barang` (`id_barang`, `nama_barang`, `stok`, `satuan`) 
                                                    VALUES ('$idBarang','$namaBarang', '$jumlahBarangMasuk', '$satuan')"
                                                );

                                                if($simpanBarang){
                                                    //simpan data simpanan
                                                    $query = "INSERT INTO  `barang_masuk` (`id_barang_masuk`, `tgl_barang_masuk`, `id_barang`, `jumlah_brg_masuk`, `harga_satuan`, `jumlah_harga`, `status`, `id_user`) 
                                                        VALUES ('$idBarangMasuk','$tglBarangMasuk', '$idBarang', '$jumlahBarangMasuk', '$hargaSatuan', '$jumlahHarga', '$status', '$idUser')";
                                                    $simpanBarangMasuk = mysqli_query(
                                                        $koneksi,
                                                        $query
                                                    );
                                                    // var_dump($simpanBarang);
                                                    // var_dump($simpanBarangMasuk);
                                                    // die();



                                                    if (!$simpanBarangMasuk) {
                                                        // var_dump($query);
                                                        // var_dump($simpan);die();
                                                        $tersimpan = false;
                                                        
                                                    } else {
                                                        $tersimpan = true;
                                                       
                                                    }
                                                }else{
                                                    // var_dump($simpanBarang);
                                                    // var_dump($simpanBarangMasuk);
                                                    // die();
                                                    $tersimpan = false;
                                                }
                                            }     
                                        }
                                        if (!$tersimpan) {
                                            echo "
                                             <script>
                                             alert('data gagal ditambahkan');
                                             document.location.href = 'barang_masuk.php';
                                             </script>
                                             ";
                                        } else {
                                            echo "
                                             <script>
                                             document.location.href = 'barang_masuk.php';
                                             </script>
                                             ";
                                        }
                                       
                                    }
                                    
                                    ?>

                                    <div class="btn btn-md btn-danger btn-block" style="height: auto">
                                        <i class="fa fa-lock fa-md"></i>
                                        <span>Tambah Barang Masuk Urgent</span>
                                    </div>
                                        </div>
                                       
                                    
                                    <?php
                                        //membuat ID Simpanan
                                        $text           = "B";
                                        $query          = mysqli_query($koneksi, "SELECT max(id_barang) AS last FROM barang");
                                        $data1          = mysqli_fetch_array($query);
                                        $lastNoAnggota  = $data1['last'];
                                        $lastNoUrut1    = substr($lastNoAnggota, 1, 4);
                                       

                                        for($i = 0; $i <$jmlform;$i++) { 
                                            $nextNoUrut1    = $lastNoUrut1 + 1 + $i;
                                            $nextNoBarang = $text . $nextNoUrut1;

                                    ?>
                                        <div class="col-md-6">
                                    <br>
                                    <div class="form-group row">
                                        <label for="id_barang_masuk<?= $i; ?>" class="col-sm-4 col-form-label text-right">ID Barang Masuk :</label>
                                        <div class="col-sm-8">
                                            <div class="md-form mt-0">
                                                <input class="form-control" type="text" value="<?='BM-'.date('ymdHis').$i;?>" name="id_barang_masuk<?= $i; ?>" readonly >
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="tgl_barang_masuk<?= $i; ?>" class="col-sm-4 col-form-label text-right" style="font-size: 15px">Tanggal Barang Masuk :</label>
                                        <div class="col-sm-8">
                                            <div class="md-form mt-0">
                                                <div class="form-group row">
                                                    <div class="col-sm-8">
                                                        <input type="date" value="<?= date('Y-m-d'); ?>" class="form-control" id="tgl_barang_masuk<?= $i; ?>" name="tgl_barang_masuk<?= $i; ?>" required>
                                                        <div class="valid-feedback">Valid.</div>
                                                        <div class="invalid-feedback">Harap isi kolom ini.</div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="id_transaksi<?= $i; ?>" class="col-sm-4 col-form-label text-right">ID Barang :</label>
                                        <div class="col-sm-8">
                                            <div class="md-form mt-0">
                                                <input class="form-control" type="text"  name="id_barang<?= $i; ?>" value="<?=$nextNoBarang?>" readonly>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="form-group row">
                                        <label for="nama_barang<?= $i; ?>" class="col-sm-4 col-form-label text-right">Nama Barang :</label>
                                        <div class="col-sm-8">
                                            <div class="md-form mt-0">
                                                <input type="text" class="form-control text-right" id="nama_barang<?= $i; ?>" placeholder="Masukan Nama Barang" name="nama_barang<?= $i; ?>" required>
                                                <div class="valid-feedback">Valid.</div>
                                                <div class="invalid-feedback">Harap isi kolom ini.</div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="id_satuan<?= $i; ?>" class="col-sm-4 col-form-label text-right">Satuan :</label>
                                        <div class="col-sm-8">
                                            <div class="md-form mt-0">
                                                <select name="id_satuan<?= $i; ?>" class="form-control" id="exampleSelectGender">
                                                    <option selected value="0" readonly>-- Pilih Satuan --</option>
                                                            <?php
                                                                $sql_a = mysqli_query($koneksi, "SELECT * FROM satuan");
                                                                while ($a = mysqli_fetch_array($sql_a)) {
                                                             ?>
                                                     <option value="<?= $a['id_satuan'] ?>"><?= $a['nama_satuan'] ?></option>
                                                            <?php } ?>
                                            </select>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                              
                               <div class="col-md-6">

                                    <div class="form-group row">
                                        <label for="jumlah_brg_masuk<?= $i; ?>" class="col-sm-4 col-form-label text-right">Jumlah Barang Masuk :</label>
                                        <div class="col-sm-8">
                                            <div class="md-form mt-0">
                                                <input type="number" class="form-control text-right" id="jumlah_brg_masuk<?= $i; ?>" placeholder="0.00" name="jumlah_brg_masuk<?= $i; ?>" required>
                                                <div class="valid-feedback">Valid.</div>
                                                <div class="invalid-feedback">Harap isi kolom ini.</div>
                                            </div>
                                        </div>
                                    </div>


                               

                                    <div class="form-group row">
                                        <label for="harga_satuan<?= $i; ?>" class="col-sm-4 col-form-label text-right">Harga Satuan :</label>
                                        <div class="col-sm-8">
                                            <div class="md-form mt-0">
                                                <input type="number" class="form-control text-right" id="harga_satuan<?= $i; ?>" placeholder="0.00" name="harga_satuan<?= $i; ?>" required>
                                                <div class="valid-feedback">Valid.</div>
                                                <div class="invalid-feedback">Harap isi kolom ini.</div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="jumlah_harga<?= $i; ?>" class="col-sm-4 col-form-label text-right">Jumlah Harga :</label>
                                        <div class="col-sm-8">
                                            <div class="md-form mt-0">
                                                <input type="number" class="form-control text-right" id="jumlah_harga<?= $i; ?>" placeholder="0.00" name="jumlah_harga<?= $i; ?>" readonly>
                                                <div class="valid-feedback">Valid.</div>
                                                <div class="invalid-feedback">Harap isi kolom ini.</div>
                                            </div>
                                        </div>
                                    </div>


                                    <!-- <div class="form-group row">
                                        <label for="status<?= $i; ?>" class="col-sm-4 col-form-label text-right">Status :</label>
                                        <div class="col-sm-8">
                                            <div class="md-form mt-0">
                                                <input type="text" class="form-control text-right" id="status<?= $i; ?>" placeholder="" name="status<?= $i; ?>" required>
                                                <div class="valid-feedback">Valid.</div>
                                                <div class="invalid-feedback">Harap isi kolom ini.</div>
                                            </div>
                                        </div>
                                    </div>
                                

                                    <div class="form-group row">
                                        <label for="id_user<?= $i; ?>" class="col-sm-4 col-form-label text-right">User :</label>
                                        <div class="col-sm-8">
                                            <div class="md-form mt-0">
                                                <input type="text" class="form-control text-right" id="id_user<?= $i; ?>r" placeholder="" name="id_user<?= $i; ?>" required>
                                                <div class="valid-feedback">Valid.</div>
                                                <div class="invalid-feedback">Harap isi kolom ini.</div>
                                            </div>
                                        </div>
                                    </div> -->

                                  
                                </div>
                                <div class="col-md-12">
                                    <hr>
                                </div>
                                
                                <?php
                                    }
                                ?>
                                 <div class="form-group row">
                                        <label for="" class="col-sm-4 col-form-label text-right"></label>
                                        <div class="col-sm-8">
                                            <div class="md-form mt-0">
                                                <input type="submit" value="Simpan" name="simpan" class="btn btn-success" style="margin-top: 5px; height: auto" />
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        </form>
                        </div>
                </div>
            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<?php 
    for($numberForm = 0;$numberForm <= $jmlform; $numberForm++) {
?>

<script type="text/javascript">
    $("#jumlah_brg_masuk<?php echo $numberForm; ?>").change(function(){
        jumlah_brg_masuk = $(this).val();
        console.log(jumlah_brg_masuk);
        harga_satuan =  $("#harga_satuan<?php echo $numberForm; ?>").val();
        total = parseInt(jumlah_brg_masuk) * parseInt(harga_satuan);
        $("#jumlah_harga<?php echo $numberForm; ?>").val(total);

    });
    $("#harga_satuan<?php echo $numberForm; ?>").change(function(){
        harga_satuan = $(this).val();
        console.log(harga_satuan);
        jumlah_brg_masuk =  $("#jumlah_brg_masuk<?php echo $numberForm; ?>").val();
        total = parseInt(jumlah_brg_masuk) * parseInt(harga_satuan);
        $("#jumlah_harga<?php echo $numberForm; ?>").val(total);
    });
</script>

<?php } ?>