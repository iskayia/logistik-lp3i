<?php include "header_pimpinan.php"; ?>
    <div class="main-panel">
        <div class="content">
            <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Beranda</h4>
                <div class="btn-group btn-group-page-header ml-auto">
                    <button type="button" class="btn btn-light btn-round btn-page-header-dropdown dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa fa-ellipsis-h"></i>
                    </button>

                    <div class="dropdown-menu">
                        <div class="arrow"></div>
                        <a class="dropdown-item" href="#">Action</a>
                        <a class="dropdown-item" href="#">Another action</a>
                        <a class="dropdown-item" href="#">Something else here</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">Separated link</a>
                    </div>

                </div>
            </div>

            <div class="row">
                <div class="col-sm-6 col-md-3">
                    <div class="card card-stats card-round">
                        <div class="card-body ">
                            <div class="row align-items-center">
                                <div class="col-icon">
                                    <div class="icon-big text-center icon-primary bubble-shadow-small">
                                        <i class="fas fa-users"></i>
                                    </div>
                                </div>
                                <div class="col col-stats ml-3 ml-sm-0">
                                    <div class="numbers">
                                        <?php

                                            $sql = "SELECT COUNT(jml_brg_keluar) AS tbk FROM `barang_keluar`";
                                            $query = mysqli_query($koneksi,$sql);
                                            $result= mysqli_fetch_array($query);
                                            
                                        ?>
                                        <p class="card-category">Transaksi Barang Keluar</p>
                                        <h4 class="card-title"><?= $result['tbk'];?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="card card-stats card-round">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-icon">
                                    <div class="icon-big text-center icon-info bubble-shadow-small">
                                        <i class="far fa-newspaper"></i>
                                    </div>
                                </div>
                                <div class="col col-stats ml-3 ml-sm-0">
                                    <div cl ass="numbers">
                                         <?php

                                            $sql = "SELECT COUNT(jumlah_brg_masuk) AS tbm FROM `barang_masuk`";
                                            $query = mysqli_query($koneksi,$sql);
                                            $result= mysqli_fetch_array($query);
                                            
                                        ?>
                                        <p class="card-category">Transaksi Barang Masuk</p>
                                        <h4 class="card-title"><?= $result['tbm']?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="card card-stats card-round">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-icon">
                                    <div class="icon-big text-center icon-success bubble-shadow-small">
                                        <i class="far fa-chart-bar"></i>
                                    </div>
                                </div>
                                <div class="col col-stats ml-3 ml-sm-0">
                                    <div class="numbers">
                                         <?php

                                            $sql = "SELECT SUM(stok) as stk FROM `barang`";
                                            $query = mysqli_query($koneksi,$sql);
                                            $result= mysqli_fetch_array($query);
                                            
                                        ?>
                                        <p class="card-category">Stok</p>
                                        <h4 class="card-title"><?= $result['stk']?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="card card-stats card-round">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-icon">
                                    <div class="icon-big text-center icon-secondary bubble-shadow-small">
                                        <i class="far fa-check-circle"></i>
                                    </div>
                                </div>
                                <div class="col col-stats ml-3 ml-sm-0">
                                    <div class="numbers">
                                        <p class="card-category">Order</p>
                                        <h4 class="card-title">576</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <!-- chart -->

                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">Chart with HTML Legends</div>
                                </div>
                                <div class="card-body">
                                    <div class="card-sub">
                                        Sometimes you need a very complex legend. In these cases, it makes sense to generate an HTML legend. Charts provide a generateLegend() method on their prototype that returns an HTML string for the legend.
                                    </div>
                                    <div class="chart-container">
                                        <canvas id="htmlLegendsChart"></canvas>
                                    </div>
                                    <div id="myChartLegend"></div>
                                </div>
                            </div>
                        </div>
                <!-- tutupchart -->
                 </div>

                   

    <?php include "footer_pimpinan.php"; ?>