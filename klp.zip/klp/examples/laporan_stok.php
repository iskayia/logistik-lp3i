<?php $menu = 'pengajuan'; ?>
<?php include 'header.php'; ?>

<?php
//membuat format rupiah dengan PHP
//tutorial www.malasngoding.com

function rupiah($angka)
{

    $hasil_rupiah = "" . number_format($angka, 0, '', '.');
    return $hasil_rupiah;
}

function rp($angka)
{

    $hasil_rupiah = "Rp. " . number_format($angka, 0, '', '.');
    return $hasil_rupiah;
}
?>
<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card card-stats card-round">
                        <div class="card-body ">
							

							<div style="overflow-x: auto;">
                                <table class=" table table-bordered display nowrap fixed" id="tabel-data" style="font-size: 16px;" >
                                    <!-- <col width="90px">
                                    <col width="150px">
                                    <col width="200px">
                                    <col width="150px">
                                    <col width="150px"> -->
                                    <thead>
                                        <tr align="center">
                                            <th>Nama Laporan</th>
                                            <th>Cetak</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                            <tr>
                                               
                                                <td align="center">Laporan Stok Barang</td>
                                                <td align="center"><a href="pdf.php" target="_blank"><button class="btn btn-primary btn-sm"><i class="fa fa-print" aria-hidden="true"></i> CETAK</button></a></td>
                                                
                                       
                                    </tbody>
                                </table>
                               
                            </div>
                            
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>        



    

<?php include 'footer.php'; ?>