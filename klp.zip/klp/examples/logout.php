<?php
session_start();
unset($_SESSION['username']);
unset($_SESSION['login']);
unset($_SESSION['id_user']); 
unset($_SESSION['level']);    
unset($_SESSION['password']);      
unset($_SESSION['nama_lengkap']);  
unset($_SESSION['email']);     		

session_destroy();
header("Location:login.php");
?>