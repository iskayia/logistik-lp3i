<?php include 'header.php'; ?>

<div class="main-content">
    <div class="container-fluid">
        <!-- <ol class="breadcrumb mb-4" style="font-size: 16px">
            <li><i class="fa fa-home" aria-hidden="true"></i></li>
            <li class="breadcrumb-item" style="margin-left: 10px"><a href="index.php">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="simpanan_wajib.php">Simpanan</a></li>
            <li class="breadcrumb-item no-drop active">Tambah Simpanan</li>

        </ol> -->
        <div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card card-stats card-round">
                        <div class="card-body ">

                        <div class="row clearfix" >
                            <a href="barang.php"><button type="button" class="btn btn-danger btn-sm"><i class="ik ik-arrow-left"></i>&nbsp; Kembali</button></a>
                        </div>

                        <br>
                        <form method="post" action="" class="was-validated font-weight-small">
                            <div class="row">
                                <div class="col-md-6" >
                                    <?php
                                    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

                                        $idBarang     = $_POST['id_barang'];
                                        $namaBarang   = $_POST['nama_barang'];
                                        $stok         = $_POST['stok'];
                                        // $tgl          = $_POST['tanggal'];
                                        // $user         = $_POST['id_user'];
                                        $satuan       = $_POST['satuan'];
                                       


                                        if ($namaBarang == '' | $stok == '' | $satuan == '') {
                                            echo "<div class='alert alert-warning fade show alert-dismissible mt-2'>
                                                        Data Belum lengkap !!!
                                                    </div>";
                                        } else {
                                            //simpan data simpanan
                                            $simpan = mysqli_query(
                                                $koneksi,
                                                "INSERT INTO  `barang` (`id_barang`, `nama_barang`, `stok`, `satuan`) 
                                                VALUES ('$idBarang','$namaBarang', '$stok', '$satuan')"
                                            );

                                            if (!$simpan) {
                                                echo "
                                                 <script>
                                                 alert('data gagal ditambahkan');
                                                 document.location.href = 'barang.php';
                                                 </script>
                                                 ";
                                            } else {
                                                echo "
                                                 <script>
                                                 document.location.href = 'barang.php';
                                                 </script>
                                                 ";
                                            }
                                        }
                                    }
                                    //membuat ID Simpanan
                                    $text           = "B";
                                    $query          = mysqli_query($koneksi, "SELECT max(id_barang) AS last FROM barang");
                                    $data1          = mysqli_fetch_array($query);
                                    $lastNoAnggota  = $data1['last'];
                                    $lastNoUrut1    = substr($lastNoAnggota, 1, 4);
                                    $nextNoUrut1    = $lastNoUrut1 + 1;
                                    // $nextNoJenisSimpanan = $text . sprintf('%s', $nextNoUrut1);
                                     $nextNoJenisSimpanan = $text . $nextNoUrut1;
                                    ?>

                                    <div class="btn btn-md btn-danger btn-block" style="height: auto">
                                        <i class="fa fa-lock fa-md"></i>
                                        <span>Tambah Barang</span>
                                    </div>

                                    <br>
                                    <div class="form-group row">
                                        <label for="id_transaksi" class="col-sm-4 col-form-label text-right">ID Barang :</label>
                                        <div class="col-sm-8">
                                            <div class="md-form mt-0">
                                                <input class="form-control" type="text"  name="id_barang" value="<?=$nextNoJenisSimpanan?>" readonly>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="tgl_transaksi" class="col-sm-4 col-form-label text-right" style="font-size: 15px">Tanggal Entri :</label>
                                        <div class="col-sm-8">
                                            <div class="md-form mt-0">
                                                <div class="form-group row">
                                                    <div class="col-sm-8">
                                                        <input type="date" value="<?= date('Y-m-d'); ?>" class="form-control" id="tgl_transaksi" name="tgl_transaksi" required>
                                                        <div class="valid-feedback">Valid.</div>
                                                        <div class="invalid-feedback">Harap isi kolom ini.</div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div> 

                                    <div class="form-group row">
                                        <label for="id_barang" class="col-sm-4 col-form-label text-right">Nama Barang :</label>
                                        <div class="col-sm-8">
                                            <div class="md-form mt-0">
                                                <input class="form-control" type="text" placeholder="Masukan Nama Barang" name="nama_barang" required>
                                                <div class="valid-feedback">Valid.</div>
                                                <div class="invalid-feedback">Harap isi kolom ini.</div>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="form-group row">
                                        <label for="jumlah_masuk" class="col-sm-4 col-form-label text-right">Stok :</label>
                                        <div class="col-sm-8">
                                            <div class="md-form mt-0">
                                                <input type="number" class="form-control text-right"  placeholder="0.00" name="stok" required>
                                                <div class="valid-feedback">Valid.</div>
                                                <div class="invalid-feedback">Harap isi kolom ini.</div>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="form-group row">
                                        <label for="satuan" class="col-sm-4 col-form-label text-right">Satuan :</label>
                                        <div class="col-sm-8">
                                            <select name="satuan" class="form-control" id="exampleSelectGender">
                                                    <option selected value="0" readonly>-- Pilih Satuan --</option>
                                                            <?php
                                                                $sql_a = mysqli_query($koneksi, "SELECT * FROM satuan");
                                                                while ($a = mysqli_fetch_array($sql_a)) {
                                                             ?>
                                                     <option value="<?= $a['id_satuan'] ?>"><?= $a['nama_satuan'] ?></option>
                                                            <?php } ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="" class="col-sm-4 col-form-label text-right"></label>
                                        <div class="col-sm-8">
                                            <div class="md-form mt-0">
                                                <input type="submit" value="Simpan" name="simpan" class="btn btn-success" style="margin-top: 5px; height: auto" />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </form>
                        </div>
                </div>
            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>