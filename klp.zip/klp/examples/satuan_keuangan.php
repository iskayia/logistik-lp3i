<?php $menu = 'pengajuanS'; ?>
<?php include 'header_keuangan.php'; ?>

<?php
//membuat format rupiah dengan PHP
//tutorial www.malasngoding.com

function rupiah($angka)
{

    $hasil_rupiah = "" . number_format($angka, 0, '', '.');
    return $hasil_rupiah;
}

function rp($angka)
{

    $hasil_rupiah = "Rp. " . number_format($angka, 0, '', '.');
    return $hasil_rupiah;
}
?>
<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card card-stats card-round">
                        <div class="card-body ">
                            <div class="ml-3">
                            <!-- <a href="tambah_satuan.php" class="btn btn-primary btn-xs">Tambah Data</a> -->
                            </div>
                            <br>
                            <div style="overflow-x: auto;">
                                <table class=" table table-bordered display nowrap fixed" id="tabel-data" style="font-size: 16px;" id="tabel-data">
                                    <col width="50px">
                                    <col width="150px">
                                    <col width="150px">
                                    <thead>
                                        <tr align="center">
                                            <th>No</th>
                                            <th>Nama Satuan</th>
                                            <!-- <th>Action</th> -->
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php


                                        //     $Halaman = 1;

                                        // if(isset($_GET['page'])){
                                        //     $Halaman= $_GET['page'];
                                        // } 
                                        // $Rows = 10;
                                        // $Record = ($Halaman - 1) * $Rows;
                                        

                                        $sql = mysqli_query($koneksi, "SELECT * FROM satuan ORDER BY id_satuan ASC ");
                                        while ($s = mysqli_fetch_array($sql)) {
                                        ?>
                                            <tr>
                                                <td align="center"><?= $s["id_satuan"]; ?></td>
                                                <td align="center"><?= $s["nama_satuan"]; ?></td>
                                                <!-- <td align="center"><a href="edit_satuan.php?id_satuan=<?= $s['id_satuan']; ?>" class='far fa-edit'></a>
                                                    <a href="hapus_satuan.php?id_satuan=<?= $s['id_satuan'] ?>" class='far fa-trash-alt'></a>
                                                </td> -->
                                               
                                                <!-- <td align="right"><?= rupiah($s["status"]); ?></td> -->
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                                <!--  <?php
                                $PrevPage = $Halaman - 1;
                                if($PrevPage < 1) $PrevPage = 1;
                                ?>
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                      <a href="?page=<?= $PrevPage; ?>" type="button" class="btn btn-secondary">
                                          <i class="fas fa-arrow-left"></i>
                                      </a>
                                      <a href="?page=<?= $Halaman + 1; ?>" type="button" class="btn btn-secondary">
                                           <i class="fas fa-arrow-right"></i>
                                      </a>
                                    </div> -->

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>        

<script>
    $(document).ready(function(){
        $('#tabel-data').DataTable();
    });
</script> 
<?php include 'footer_keuangan.php'; ?>