<?php $menu = 'pengajuan'; ?>
<?php include 'header.php'; ?>

<?php
//membuat format rupiah dengan PHP
//tutorial www.malasngoding.com

function rupiah($angka)
{

    $hasil_rupiah = "" . number_format($angka, 0, '', '.');
    return $hasil_rupiah;
}

function rp($angka)
{

    $hasil_rupiah = "Rp. " . number_format($angka, 0, '', '.');
    return $hasil_rupiah;
}
?>
<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card card-stats card-round">
                        <div class="card-body ">

                            <div class="ml-3">
                            <a href="orke_dev.php" class="btn btn-primary btn-xs"><i class="fa fa-plus"></i> Tambah Data</a>
                            </div>
                            
                            <br>
                            
                            <div style="overflow-x: auto;">
                                <table class=" table table-bordered display nowrap fixed" id="tabel-data" style="font-size: 16px;" id="tabel-data">
                                    <col width="50px">
                                    <col width="150px">
                                    <col width="150px">
                                    <col width="150px">
                                    <col width="150px">
                                    <!-- <col width="150px"> -->
                                    <thead>
                                        <tr align="center">
                                            <th>No</th>
                                            <th>ID Barang</th>
                                            <th>Nama Barang</th>
                                            <th>Jumlah Barang Keluar</th>
                                            <th>Tanggal Transaksi</th>
                                            <!-- <th>Action</th> -->
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i = 1 ?>
                                        <?php
                                        $sql = mysqli_query($koneksi, "SELECT id_barang_keluar,nama_barang,jml_brg_keluar,tgl_brg_keluar FROM barang_keluar INNER JOIN barang ON barang_keluar.id_barang = barang.id_barang ORDER by id_barang_keluar DESC ");
                                        while ($s = mysqli_fetch_array($sql)) {
                                        ?>
                                            <tr>
                                                <td align="center"><?= $i++; ?></td>
                                                <td align="center"><?= $s["id_barang_keluar"]; ?></td>
                                                <td align="center"><?= $s["nama_barang"]; ?></td>
                                                <td align="center"><?= $s["jml_brg_keluar"]; ?></td>
                                                <td align="center"><?= $s["tgl_brg_keluar"]; ?></td>
                                               <!--  <td align="center"><i class='far fa-edit'></i>
                                                    <i class='far fa-trash-alt'></i>
                                                </td> -->
                                               
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>  

<script>
    $(document).ready(function(){
        $('#tabel-data').DataTable();
    });
</script>

<?php include 'footer.php'; ?>